# Danish Headshot Pro Max

An English-language Android starter app for Free Fire MAX players. Includes manual sensitivity starting ranges, HUD guidance, DPI information, and an offline tap-reaction trainer.

## Fair-play and safety
This app does not automate aiming, read or modify Free Fire MAX, inject code, overlay game controls, or promise automatic headshots. It is a practice/configuration companion only. Sensitivity ranges are starting points, not guaranteed settings.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

Package: `com.danish.headshotpro`  
Minimum Android: 6.0 (API 23)
